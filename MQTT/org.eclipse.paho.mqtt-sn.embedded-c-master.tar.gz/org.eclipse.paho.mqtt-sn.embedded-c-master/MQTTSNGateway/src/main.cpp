/*
 * main.cpp
 *
 *  Created on: Jan 5, 2016
 *      Author: icraggs
 */


void read_config()
{

}



int main(int argc, char* argv[])
{


	// 1. listen for MQTT-SN connections

	// 2. connect to MQTT broker

	// 3. listen for MQTT-SN packets, and act on them
	// 4. listen for MQTT packets too, and act on them





	return 0;
}

