var searchData=
[
  ['auto_20reconnect',['Auto Reconnect',['../AutoReconnect.html',1,'']]]
];
