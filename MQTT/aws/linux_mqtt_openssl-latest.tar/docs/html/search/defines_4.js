var searchData=
[
  ['max_5facks_5fto_5fcomein_5fat_5fany_5fgiven_5ftime',['MAX_ACKS_TO_COMEIN_AT_ANY_GIVEN_TIME',['../aws__iot__config_8h.html#a5a4c1a56ea1abf6c52893aa3c9852c7a',1,'aws_iot_config.h']]],
  ['max_5fjson_5ftoken_5fexpected',['MAX_JSON_TOKEN_EXPECTED',['../aws__iot__config_8h.html#ad68f57bee9eb5d5e704e02766fb73f9a',1,'aws_iot_config.h']]],
  ['max_5fshadow_5ftopic_5flength_5fbytes',['MAX_SHADOW_TOPIC_LENGTH_BYTES',['../aws__iot__config_8h.html#aa6da50cf5e41405ab4367a3a987e576a',1,'aws_iot_config.h']]],
  ['max_5fshadow_5ftopic_5flength_5fwithout_5fthingname',['MAX_SHADOW_TOPIC_LENGTH_WITHOUT_THINGNAME',['../aws__iot__config_8h.html#a7c8510e5cd4b15ebea2fc3268cd5bb4a',1,'aws_iot_config.h']]],
  ['max_5fsize_5fclient_5fid_5fwith_5fsequence',['MAX_SIZE_CLIENT_ID_WITH_SEQUENCE',['../aws__iot__config_8h.html#af2fa43a4252a6063ec0de1f52cf5ef13',1,'aws_iot_config.h']]],
  ['max_5fsize_5fclient_5ftoken_5fclient_5fsequence',['MAX_SIZE_CLIENT_TOKEN_CLIENT_SEQUENCE',['../aws__iot__config_8h.html#a40b29ae9b25643591d53bba30f4a2254',1,'aws_iot_config.h']]],
  ['max_5fsize_5fof_5fthing_5fname',['MAX_SIZE_OF_THING_NAME',['../aws__iot__config_8h.html#a826855d821708a27c9480a12528a16ab',1,'aws_iot_config.h']]],
  ['max_5fsize_5fof_5funique_5fclient_5fid_5fbytes',['MAX_SIZE_OF_UNIQUE_CLIENT_ID_BYTES',['../aws__iot__config_8h.html#a56207bd83241b9d3725cb1f0fcddc812',1,'aws_iot_config.h']]],
  ['max_5fthingname_5fhandled_5fat_5fany_5fgiven_5ftime',['MAX_THINGNAME_HANDLED_AT_ANY_GIVEN_TIME',['../aws__iot__config_8h.html#a939c2ffb6c613b59b9d90e18f8ace026',1,'aws_iot_config.h']]]
];
