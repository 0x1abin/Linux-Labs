var searchData=
[
  ['countdown',['countdown',['../timer_8c.html#ab9b6a721d03b085959a0f66907822629',1,'countdown(Timer *timer, unsigned int timeout):&#160;timer.c'],['../timer__interface_8h.html#acc8817569e64e1d4193b08ca2570517a',1,'countdown(Timer *, unsigned int):&#160;timer.c']]],
  ['countdown_5fms',['countdown_ms',['../timer_8c.html#a75af8f6d4820a905276fae6bac80212a',1,'countdown_ms(Timer *timer, unsigned int timeout):&#160;timer.c'],['../timer__interface_8h.html#a346afafb170b78f813bf7a15e4f2aede',1,'countdown_ms(Timer *, unsigned int):&#160;timer.c']]]
];
