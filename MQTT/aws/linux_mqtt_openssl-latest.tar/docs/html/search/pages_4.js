var searchData=
[
  ['sdk_20architecture_20and_20design',['SDK Architecture and Design',['../ArchitectureSDK.html',1,'']]]
];
