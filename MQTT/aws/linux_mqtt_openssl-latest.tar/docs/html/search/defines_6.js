var searchData=
[
  ['shadow_5fmax_5fsize_5fof_5frx_5fbuffer',['SHADOW_MAX_SIZE_OF_RX_BUFFER',['../aws__iot__config_8h.html#a3072be59f0ef2b033cd04a6deb1c5d36',1,'aws_iot_config.h']]]
];
