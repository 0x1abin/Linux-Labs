var searchData=
[
  ['shadowparameters_5ft',['ShadowParameters_t',['../structShadowParameters__t.html',1,'']]],
  ['subscriptionrecord_5ft',['SubscriptionRecord_t',['../structSubscriptionRecord__t.html',1,'']]]
];
