var searchData=
[
  ['shadow_5fack_5fstatus_5ft',['Shadow_Ack_Status_t',['../aws__iot__shadow__interface_8h.html#ad946163c2ac5df0aa896520949d47956',1,'aws_iot_shadow_interface.h']]],
  ['shadowactions_5ft',['ShadowActions_t',['../aws__iot__shadow__interface_8h.html#a1fc9e025434023d44d33737f8b7c2a8c',1,'aws_iot_shadow_interface.h']]]
];
