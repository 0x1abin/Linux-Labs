var searchData=
[
  ['tcp_5fconnect_5ferror',['TCP_CONNECT_ERROR',['../aws__iot__error_8h.html#a329da5c3a42979b72561e28e749f6921a36f69a4c64e378650da247bf213c7fe8',1,'aws_iot_error.h']]],
  ['tcp_5fsetup_5ferror',['TCP_SETUP_ERROR',['../aws__iot__error_8h.html#a329da5c3a42979b72561e28e749f6921ae8fb7fc8541edffbb584505c8ab0aa61',1,'aws_iot_error.h']]]
];
