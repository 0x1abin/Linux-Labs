var searchData=
[
  ['changelog',['CHANGELOG',['../md_CHANGELOG.html',1,'']]]
];
